#' @title Example 8.2 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   Exam8.2
#' @description Exam8.2 explains multifactor models with some factors qualitative and some quantitative(Equal slopes ANCOVA)
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'      \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'        CRC Press.
#'  }
#'
#'  @seealso
#'    \code{\link{DataSet8.2}}
#'
#' @import parameters
#' @import emmeans ggplot2
#' @importFrom car Anova
#'
#' @examples
#'
#' data(DataSet8.2)
#' DataSet8.2$trt <- factor( x = DataSet8.2$trt )
#'
#' ##----ANCOVA(Equal slope Model)
#' Exam9.2fm1 <- aov(formula = y ~ trt*x, data = DataSet8.2)
#' car::Anova(mod = Exam9.2fm1 , type = "III")
#'
#' ##---ANCOVA(without interaction because of non significant slope effect)
#' Exam9.2fm2 <- aov(formula = y ~ trt + x, data    = DataSet8.2)
#' car::Anova(mod = Exam9.2fm2 , type = "III")
#'
#' ##---Ls means for 2nd model
#' emmeans::emmeans(object  = Exam9.2fm2, specs = ~trt)
#'
#' ##---Anova without covariate
#' Exam9.2fm3 <- aov(formula = y ~ trt, data = DataSet8.2)
#' car::Anova(mod = Exam9.2fm3, type = "III")
#'
#' ##---Ls means for 3rd model
#' emmeans::emmeans(object = Exam9.2fm3, specs = ~trt)
#'
#' ##---Box Plot of Covariate by treatment
#' Plot <-
#'    ggplot2::ggplot(
#'           data    = DataSet8.2
#'         , mapping = ggplot2::aes(x = factor(trt), y = x)
#'          )                              +
#'    ggplot2::geom_boxplot(width = 0.5)  +
#'    ggplot2::coord_flip()               +
#'    ggplot2::geom_point()               +
#'    ggplot2::stat_summary(
#'          fun    = "mean"
#'        , geom   = "point"
#'        , shape  =  23
#'        , size   =  2
#'        , fill   = "red"
#'        )                               +
#'    ggplot2::theme_bw()                 +
#'    ggplot2::ggtitle("Covariate by treatment Box Plot") +
#'    ggplot2::xlab("Treatment")
#' print(Plot)
#'
NULL


