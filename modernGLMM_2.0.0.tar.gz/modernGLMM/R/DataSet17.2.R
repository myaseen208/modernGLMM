#' @title Data for Example 17.2 — Sparse Longitudinal Data with SP(POW) (Chapter 17)
#' @name   DataSet17.2
#' @docType data
#' @keywords datasets
#' @usage data(DataSet17.2)
#'
#' @description
#' Sparse longitudinal data from 41 subjects (17 on treatment 1, 24 on
#' treatment 2) observed at up to 9 unequally-spaced time points
#' (0, 1, 2, 4, 8, 16, 32, 64, 128), with only 101 of 369 possible
#' observations present.  Implements Example 17.3.2 of Stroup et al. (2024),
#' Data Set 17.2 (SAS name \code{all}).  Demonstrates the SP(POW) spatial-power
#' covariance as a generalisation of AR(1) to irregular time grids.
#'
#' \strong{Reconstruction note:} The actual data appear in the SAS Data and
#' Program Library as Data Set 17.2.  This version is reconstructed from the
#' published design description (41 subjects, 9 unequal times, sparse 101/369
#' observations) and published random coefficient model parameters (pp.516-518)
#' using \code{set.seed(2024)}.  Published AICC and parameter estimates will
#' not be reproduced exactly.
#'
#' @format A \code{data.frame} with 101 rows and 4 variables:
#' \describe{
#'   \item{subject}{Subject identifier (factor with 41 levels)}
#'   \item{trt}{Treatment factor with 2 levels (1, 2);
#'     17 subjects on trt=1, 24 subjects on trt=2}
#'   \item{time}{Actual time of measurement: one of 0, 1, 2, 4, 8, 16, 32,
#'     64, 128 (continuous; unequally spaced)}
#'   \item{y}{Continuous Gaussian response}
#' }
#'
#' @details
#' For unequally-spaced observations, the SP(POW) covariance between
#' observations at times \eqn{X_j} and \eqn{X_{j'}} on the same subject is:
#' \deqn{\text{Cov}(e_j, e_{j'}) = \sigma^2 \rho^{|X_j - X_{j'|}}}
#' Unlike AR(1), SP(POW) accommodates unequal spacing and missing observations.
#' The random coefficient model is:
#' \deqn{y_{ik} = \beta_{0i} + b_{0k} + (\beta_{1i} + b_{1k}) X_j + e_{ijk}}
#' where \eqn{b_{0k}} and \eqn{b_{1k}} are random intercept and slope.
#'
#' Published results (2nd ed. pp.517-518):
#' Best = heterogeneous SP(POW) by treatment, AICC=575.96;
#' Homogeneity test: \eqn{\chi^2}=8.65, p=0.0132.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts,
#'     Methods and Applications}. CRC Press. Section 17.3.2, pp.516-518.
#'   \item Littell, R.C., Milliken, G.A., Stroup, W.W., Wolfinger, R.D.,
#'     & Schabenberger, O. (2006). \emph{SAS for Mixed Models}, 2nd ed.
#'     SAS Institute.
#' }
#'
#' @seealso \code{\link{Exam17.2}}
#'
#' @examples
#' data(DataSet17.2)
#' str(DataSet17.2)
#' cat("Observations per treatment:\n")
#' print(table(DataSet17.2$trt))
#' cat("Sparsity:", nrow(DataSet17.2), "of",
#'     length(unique(DataSet17.2$subject)) * 9, "possible\n")
NULL
