#' Example 11.1 - CRD Count Data and Poisson-Normal GLMM
#'
#' @name Exam11.1
#'
#' @description
#' Reproduces the Chapter 11, Section 11.1.2 workflow comparing an ANOVA on
#' counts, an ANOVA on log counts, a Poisson GLM, and a Poisson-normal GLMM
#' with an observation-level random effect.
#'
#' @details
#' The Poisson-normal GLMM is
#' \deqn{\log(\lambda_{ij}) = \eta + \tau_i + u_{ij}, \quad
#'       u_{ij} \sim N(0, \sigma_U^2).}
#'
#' @note
#' The count and log-count ANOVA outputs reproduce the printed book values.
#' The Poisson-normal GLMM is fitted with \pkg{lme4}; small differences from
#' SAS PROC GLIMMIX are expected because the estimation algorithms differ.
#'
#' @references
#' Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#' \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#' Applications}, 2nd ed. CRC Press.
#'
#' @seealso \code{\link{DataSet11.1}}
#'
#' @examples
#' data(DataSet11.1)
#'
#' fit_count <- stats::lm(count ~ trt, data = DataSet11.1)
#' stats::anova(fit_count)
#'
#' DataSet11.1$log_count <- log(DataSet11.1$count)
#' fit_log <- stats::lm(log_count ~ trt, data = DataSet11.1)
#' stats::anova(fit_log)
#' emmeans::emmeans(fit_log, specs = ~ trt)
#'
#' fit_glm <- stats::glm(
#'   count ~ trt,
#'   family = stats::poisson(link = "log"),
#'   data = DataSet11.1
#' )
#' emmeans::emmeans(fit_glm, specs = ~ trt, type = "response")
#'
#' if (requireNamespace("lme4", quietly = TRUE)) {
#'   fit_glmm <- lme4::glmer(
#'     count ~ trt + (1 | trt:unit),
#'     family = stats::poisson(link = "log"),
#'     data = DataSet11.1,
#'     nAGQ = 0,
#'     control = lme4::glmerControl(optimizer = "bobyqa")
#'   )
#'   summary(fit_glmm)
#'   lme4::VarCorr(fit_glmm)
#'   emmeans::emmeans(fit_glmm, specs = ~ trt, type = "response")
#'
#'   if (requireNamespace("DHARMa", quietly = TRUE)) {
#'     sim_res <- DHARMa::simulateResiduals(fit_glmm, plot = FALSE)
#'     DHARMa::testDispersion(sim_res)
#'   }
#'
#'   if (requireNamespace("report", quietly = TRUE)) {
#'     report::report(fit_glmm)
#'   }
#' }
NULL
