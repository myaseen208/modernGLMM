#' @title Example 17.1 — Repeated Measures: Crossover with ARH(1) Covariance
#' @name   Exam17.1
#'
#' @description
#' Analysis of a two-treatment crossover study (41 subjects, 6 equally-spaced
#' time points per period, baseline covariate) using a random coefficient model
#' with covariance model selection.  Implements Example 17.3.1 of Stroup et al.
#' (2024), Data Set 17.1.  The best-fitting within-subject covariance structure
#' is ARH(1) (heterogeneous AR(1)), selected by AICC comparison.
#'
#' @details
#' The model for subject \eqn{k} on treatment \eqn{i} in period \eqn{p} at
#' time \eqn{T_j} is:
#' \deqn{y_{ijkl} = \beta_{0i} + b_{0ik} + (\beta_{1i} + b_{1ik}) T_j +
#'       \rho_p + \beta_b X_k + e_{ijkl}}
#' where \eqn{\beta_{0i}} and \eqn{\beta_{1i}} are the treatment-specific
#' intercept and time slope, \eqn{b_{0ik}} and \eqn{b_{1ik}} are the
#' subject-specific random intercept and slope, \eqn{\rho_p} is the period
#' effect, \eqn{X_k} is the baseline covariate, and \eqn{e_{ijkl}} follows
#' an ARH(1) structure.
#'
#' Published results (2nd ed. p.516):
#' Best covariance = ARH(1), AICC=3035.25.
#' Key contrasts: Equal intercepts F(1,526)=1.16, p=0.2818;
#' Equal slopes F(1,104)=4.18, p=0.0434 (slopes differ between treatments).
#'
#' @note
#' \strong{Dataset note:} \code{DataSet17.1} is reconstructed from the
#' published design description: 41 subjects (17 in sequence 0→1, 24 in
#' sequence 1→0), 2 periods × 6 time points each + baseline covariate =
#' 492 observations.  Synthetic response values are generated using the
#' published regression contrasts as the approximate generative model.
#' The actual data appear in the SAS Data and Program Library as Data Set 17.1
#' (SAS name \code{x_over_ante1}).  Published AICC and F-statistics will
#' not be reproduced exactly.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#'     Applications}. CRC Press. Section 17.3.1, pp.513–516.
#'   \item Verbeke, G., & Molenberghs, G. (2000).
#'     \emph{Linear Mixed Models for Longitudinal Data}. Springer.
#' }
#'
#' @seealso \code{\link{DataSet17.1}}
#'
#' @examples
#' data(DataSet17.1)
#'
#' ## -------------------------------------------------------
#' ## 1. Covariance model selection via AICC (CS, AR(1), ARH(1))
#' ## -------------------------------------------------------
#'
#' ## CS: compound symmetry ~ random subject intercept within id(trt*period)
#' fit_cs <- nlme::lme(
#'   fixed     = y ~ period + trt / t + baseline,
#'   random    = ~ 1 | id,
#'   data      = DataSet17.1,
#'   method    = "REML"
#' )
#'
#' ## AR(1): via corAR1 on equally-spaced times within subject-period
#' fit_ar1 <- nlme::lme(
#'   fixed       = y ~ period + trt / t + baseline,
#'   random      = list(id = nlme::pdDiag(~ t)),
#'   correlation = nlme::corAR1(form = ~ t | id / period),
#'   data        = DataSet17.1,
#'   method      = "REML"
#' )
#'
#' ## ARH(1): heterogeneous variances per time + AR(1) within period
#' fit_arh1 <- nlme::lme(
#'   fixed       = y ~ period + trt / t + baseline,
#'   random      = list(id = nlme::pdDiag(~ t)),
#'   correlation = nlme::corAR1(form = ~ t | id / period),
#'   weights     = nlme::varIdent(form = ~ 1 | t),
#'   data        = DataSet17.1,
#'   method      = "REML"
#' )
#'
#' ## AICC comparison (best model = ARH(1) in book; may differ on reconstructed data)
#' stats::AIC(fit_cs, fit_ar1, fit_arh1)
#'
#' ## -------------------------------------------------------
#' ## 2. Key contrasts: equal intercepts, equal slopes
#' ## -------------------------------------------------------
#' emm_int <- emmeans::emmeans(fit_arh1, ~ trt, at = list(t = 0))
#' emmeans::contrast(emm_int, method = "pairwise")
#'
#' emm_slp <- emmeans::emtrends(fit_arh1, ~ trt, var = "t")
#' emmeans::contrast(emm_slp, method = "pairwise")
#'
#' ## -------------------------------------------------------
#' ## 3. Treatment × time interaction profile
#' ## -------------------------------------------------------
#' emm_trt_t <- emmeans::emmeans(fit_arh1, ~ trt | t,
#'                                at = list(t = 0:5))
#' print(emm_trt_t)
NULL
