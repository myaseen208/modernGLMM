#' Example 11.3 - Blocked Count Data and Overdispersion
#'
#' @name Exam11.3
#'
#' @description
#' Fits the Chapter 11 blocked-design count-data models from Section 11.4:
#' a naive Poisson GLMM, a Poisson-normal GLMM with a block-by-treatment unit
#' effect, and a negative-binomial GLMM.
#'
#' @details
#' The naive Poisson model is
#' \deqn{\log(\lambda_{ij}) = \eta + \tau_i + r_j,\quad
#'       r_j \sim N(0,\sigma_R^2).}
#' The Poisson-normal model adds a unit term
#' \deqn{\log(\lambda_{ij}) = \eta + \tau_i + r_j + (rt)_{ij}.}
#' The negative-binomial model omits the unit term and uses the distributional
#' scale parameter to account for unit-level overdispersion.
#'
#' @note
#' \pkg{glmmTMB} uses the \code{nbinom2} parameterization
#' \eqn{Var(Y) = \mu + \mu^2/\theta}. The book's negative-binomial scale
#' \eqn{\phi} corresponds approximately to \eqn{1/\theta}.
#'
#' @references
#' Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#' \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#' Applications}, 2nd ed. CRC Press.
#'
#' @seealso \code{\link{DataSet11.3}}
#'
#' @examples
#' data(DataSet11.3)
#'
#' if (requireNamespace("lme4", quietly = TRUE)) {
#'   fit_naive <- lme4::glmer(
#'     count ~ trt + (1 | block),
#'     family = stats::poisson(link = "log"),
#'     data = DataSet11.3,
#'     nAGQ = 1,
#'     control = lme4::glmerControl(optimizer = "bobyqa")
#'   )
#'   pearson_df <- sum(stats::residuals(fit_naive, type = "pearson")^2) /
#'     stats::df.residual(fit_naive)
#'   pearson_df
#'   emmeans::emmeans(fit_naive, specs = ~ trt, type = "response")
#'
#'   fit_pois_normal <- lme4::glmer(
#'     count ~ trt + (1 | block) + (1 | block:trt),
#'     family = stats::poisson(link = "log"),
#'     data = DataSet11.3,
#'     nAGQ = 0,
#'     control = lme4::glmerControl(optimizer = "bobyqa")
#'   )
#'   lme4::VarCorr(fit_pois_normal)
#'   emmeans::emmeans(fit_pois_normal, specs = ~ trt, type = "response")
#' }
#'
#' if (requireNamespace("glmmTMB", quietly = TRUE)) {
#'   fit_nb <- glmmTMB::glmmTMB(
#'     count ~ trt + (1 | block),
#'     family = glmmTMB::nbinom2(link = "log"),
#'     data = DataSet11.3
#'   )
#'   summary(fit_nb)
#'   emmeans::emmeans(fit_nb, specs = ~ trt, type = "response")
#'
#'   if (requireNamespace("DHARMa", quietly = TRUE)) {
#'     sim_res <- DHARMa::simulateResiduals(fit_nb, plot = FALSE)
#'     DHARMa::testDispersion(sim_res)
#'   }
#'
#'   if (requireNamespace("report", quietly = TRUE)) {
#'     report::report(fit_nb)
#'   }
#' }
NULL
