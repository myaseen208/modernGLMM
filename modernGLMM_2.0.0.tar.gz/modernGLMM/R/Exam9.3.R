#' @title Example 9.3 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   Exam9.3
#' @description Exam9.3 explains Response surface design with incomplete blocking
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'      \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'        CRC Press.
#'  }
#'
#' @seealso
#'    \code{\link{DataSet9.3}}
#'
#' @import lmerTest
#' @import ggplot2
#'
#' @examples
#'
#' ## Response Surface Design with incomplete blocking
#' data(DataSet9.3)
#' DataSet9.3$block <- factor(x = DataSet9.3$block)
#' DataSet9.3$aa    <- factor(x = DataSet9.3$a)
#' DataSet9.3$bb    <- factor(x = DataSet9.3$b)
#' DataSet9.3$cc    <- factor(x = DataSet9.3$c)
#' DataSet9.3$a2    <- DataSet9.3$a^2
#' DataSet9.3$b2    <- DataSet9.3$b^2
#' DataSet9.3$c2    <- DataSet9.3$c^2
#' DataSet9.3$ab    <- DataSet9.3$a * DataSet9.3$b
#' DataSet9.3$ac    <- DataSet9.3$a * DataSet9.3$c
#' DataSet9.3$bc    <- DataSet9.3$b * DataSet9.3$c
#'
#' Exam9.3.fm1 <- lmerTest::lmer(
#'   y ~ a + a2 + b + ab + b2 + c + ac + bc + c2 +
#'       aa:bb:cc + (1 | block),
#'   data = DataSet9.3
#' )
#' stats::anova(Exam9.3.fm1, ddf = "Kenward-Roger", type = 1)
#'
#' Exam9.3.fm2 <- lmerTest::lmer(
#'   y ~ a + a2 + b + ab + b2 + c + ac + bc + c2 + (1 | block),
#'   data = DataSet9.3
#' )
#' stats::anova(Exam9.3.fm2, ddf = "Kenward-Roger", type = 1)
#'
#' Exam9.3.fm3 <- lmerTest::lmer(
#'   y ~ a + a2 + b + b2 + c + bc + (1 | block),
#'   data = DataSet9.3
#' )
#' stats::anova(Exam9.3.fm3, ddf = "Kenward-Roger", type = 1)
#'
#' ## Predicted response surface (three panels at c = -1, 0, 1)
#' agrid <- seq(from = -1, to = 1, by = 0.1)
#' bgrid <- seq(from = -1, to = 1, by = 0.1)
#' cgrid <- c(-1, 0, 1)
#' Newdata <- expand.grid(a = agrid, b = bgrid, c = cgrid)
#' Newdata$Yhat <- with(Newdata,
#'   50.08500 + 1.6*a + 1.69375*b + 0.51875*c -
#'   3.30250*a^2 - 3.51500*b^2 - 1.16250*b*c
#' )
#' Newdata$c_label <- factor(
#'   Newdata$c,
#'   levels = c(-1, 0, 1),
#'   labels = c("C = -1", "C = 0", "C = 1")
#' )
#'
#' ggplot2::ggplot(Newdata, ggplot2::aes(x = a, y = b, fill = Yhat)) +
#'   ggplot2::geom_tile() +
#'   ggplot2::scale_fill_viridis_c(option = "plasma", name = expression(hat(Y))) +
#'   ggplot2::facet_wrap(~c_label) +
#'   ggplot2::labs(
#'     title = "Predicted Response Surface",
#'     x     = "Factor A",
#'     y     = "Factor B"
#'   ) +
#'   ggplot2::theme_bw()
#'
NULL
