#' @title DataSet3.2 for Example 3.3, Example 3.4, Example3.6, Example3.8 and Example 3.9 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   DataSet3.2
#' @docType data
#' @keywords datasets
#' @usage data(DataSet3.2)
#' @description DataSet3.2 Multi-Location, 4 Treatment Randomized Block
#' @format A \code{data.frame} with 32 rows and 10 variables.
#' @details
#'        \itemize{
#'        \item trt              four treatments, coded 0, 1, 2, and 3
#'        \item loc              eight locations used as blocks
#'        \item Y                is Gaussian response variable
#'        \item Nbin             subjects at each Loc x Trt for binomial response
#'        \item S1 and S2        are two binomial response variables
#'        \item count1 and count 2 used later
#'        \item A and B          factorial treatment components with levels 0 and 1;
#'                               the mapping follows the Chapter 3, Section 3.3.5
#'                               \code{a*b} least-squares means table
#'             }
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).\emph{Generalized linear mixed models: modern concepts, methods and applications}.
#'              CRC Press.
#'  }
#' @seealso
#'    \code{\link{Exam3.3}}
#'    \code{\link{Exam3.9}}
#' @examples
#' data(DataSet3.2)
NULL
