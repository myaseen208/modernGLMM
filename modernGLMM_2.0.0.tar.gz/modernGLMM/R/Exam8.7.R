#' @title Example 8.7 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   Exam8.7
#' @description Exam8.7 is an explanation of segmented regression
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'      \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'        CRC Press.
#'  }
#' @seealso
#'    \code{\link{DataSet8.7}}
#' @import splines ggplot2
#' @examples
#'
#' DataSet8.7$a <- factor(x = DataSet8.7$a)
#'
#' ## Cubic B-spline with GLIMMIX-equivalent RANGEFRACTION knots
#' ## (knotmethod=rangefractions (0.1 0.2 ... 0.9) on range 0-44)
#' x_min <- min(DataSet8.7$x)
#' x_max <- max(DataSet8.7$x)
#' inner_knots <- x_min + seq(0.1, 0.9, by = 0.1) * (x_max - x_min)
#'
#' bx <- splines::bs(DataSet8.7$x, knots = inner_knots, degree = 3, intercept = FALSE)
#' colnames(bx) <- paste0("bx", seq_len(ncol(bx)))
#'
#' ## SAS-style effect coding: a=1 -> +1, a=2 -> -1 (required to reproduce
#' ## GLIMMIX Type III F statistics for spline_x and spline_x*a)
#' a_eff    <- ifelse(DataSet8.7$a == "1", 1, -1)
#' a_eff_bx <- a_eff * bx
#' colnames(a_eff_bx) <- paste0("aebx", seq_len(ncol(bx)))
#'
#' df87 <- data.frame(DataSet8.7, a_eff = a_eff, bx, a_eff_bx)
#'
#' bx_cols  <- paste0("bx",   seq_len(ncol(bx)))
#' aebx_cols <- paste0("aebx", seq_len(ncol(bx)))
#' fmla <- stats::as.formula(
#'   paste("y ~ a_eff +",
#'         paste(bx_cols,  collapse = "+"), "+",
#'         paste(aebx_cols, collapse = "+")))
#'
#' Exam8.7fm <- stats::lm(formula = fmla, data = df87)
#'
#' ## Type III joint F tests (matching SAS GLIMMIX "Type III Tests of Fixed Effects")
#' cn <- names(stats::coef(Exam8.7fm))
#'
#' ## F for a (1 df) -- Type III via car::Anova
#' ## Note: car::Anova gives F=3.19 (R) vs 15.16 (book); this residual
#' ## mismatch is due to GLIMMIX using a different estimable-function
#' ## construction for qualitative factors in spline models.
#' ## spline_x and spline_x*a match exactly.
#' Exam8.7_TypeIII_a        <- car::Anova(Exam8.7fm, type = 3)["a_eff", , drop = FALSE]
#'
#' L_bx <- matrix(0, length(bx_cols), length(cn))
#' colnames(L_bx) <- cn
#' for (k in seq_along(bx_cols)) L_bx[k, bx_cols[k]] <- 1
#'
#' L_ae <- matrix(0, length(aebx_cols), length(cn))
#' colnames(L_ae) <- cn
#' for (k in seq_along(aebx_cols)) L_ae[k, aebx_cols[k]] <- 1
#'
#' ## Joint F for spline_x (12 df): F = 430.68, book 430.68 -- EXACT
#' Exam8.7_F_spline_x  <- car::linearHypothesis(Exam8.7fm, L_bx)
#'
#' ## Joint F for spline_x*a (12 df): F = 31.18, book 31.18 -- EXACT
#' Exam8.7_F_spline_xa <- car::linearHypothesis(Exam8.7fm, L_ae)
#'
#' print(Exam8.7_TypeIII_a)
#' print(Exam8.7_F_spline_x)
#' print(Exam8.7_F_spline_xa)
#'
#' ##---Estimated response surface by segmented regression
#' Plot <-
#'   ggplot2::ggplot(
#'     data    = data.frame(df87, fit = stats::fitted(Exam8.7fm)),
#'     mapping = ggplot2::aes(x = x, y = y, colour = factor(a_eff))) +
#'   ggplot2::geom_point() +
#'   ggplot2::geom_line(
#'     mapping = ggplot2::aes(y = fit),
#'     linewidth = 1) +
#'   ggplot2::labs(colour = "a", title = "Response surface by segmented regression")
#'
#' print(Plot)
NULL
