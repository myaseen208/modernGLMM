#' @title Example 3.5 — Factorial Fixed Effects, Estimable Functions
#' @name   Exam3.5
#' @description
#' Example 3.5 (Stroup et al., 2024) analyses a factorial treatment
#' structure with fixed location effects using \code{DataSet3.2}.
#' Simple effects and marginal means are estimated via \pkg{emmeans}.
#'
#' @author
#' \enumerate{
#'   \item Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'   \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#' }
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'     CRC Press.
#' }
#'
#' @seealso \code{\link{DataSet3.2}}
#'
#' @importFrom stats lm
#'
#' @examples
#' data(DataSet3.2)
#' DataSet3.2$A   <- factor(x = DataSet3.2$A)
#' DataSet3.2$B   <- factor(x = DataSet3.2$B)
#' DataSet3.2$loc <- factor(x = DataSet3.2$loc, levels = c(8, 1, 2, 3, 4, 5, 6, 7))
#'
#' Exam3.5.lm <- stats::lm(formula = Y ~ A + B + loc, data = DataSet3.2)
#' Exam3.5.lm
#'
#' if (requireNamespace("emmeans", quietly = TRUE)) {
#'   ## A=0 marginal mean
#'   emmeans::contrast(
#'     object = emmeans::emmeans(object = Exam3.5.lm, specs = ~ B),
#'     list(trt = c(1, 0))
#'   )
#'
#'   ## B=0 marginal mean
#'   emmeans::contrast(
#'     object = emmeans::emmeans(object = Exam3.5.lm, specs = ~ B),
#'     list(B0 = c(1, 0))
#'   )
#'
#'   ## Simple effect of A at B0 (B = "0")
#'   emmeans::contrast(
#'     emmeans::emmeans(object = Exam3.5.lm, specs = ~ A | B),
#'     method = "pairwise",
#'     by     = "B"
#'   )
#'
#'   ## Simple effect of B at A0 (A = "0")
#'   emmeans::contrast(
#'     emmeans::emmeans(object = Exam3.5.lm, specs = ~ B | A),
#'     method = "pairwise",
#'     by     = "A"
#'   )
#'
#'   ## All A*B marginal means
#'   emmeans::emmeans(object = Exam3.5.lm, specs = ~ A * B)
#' }
NULL
