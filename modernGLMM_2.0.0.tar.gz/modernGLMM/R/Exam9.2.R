#' @title Example 9.2 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   Exam9.2
#' @description Exam9.2 Incomplete strip-plot
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'      \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'        CRC Press.
#'  }
#'
#' @seealso
#'    \code{\link{DataSet9.2}}
#'
#' @import emmeans lmerTest
#' @examples
#'
#' data(DataSet9.2)
#' DataSet9.2$block <- factor(x = DataSet9.2$block)
#' DataSet9.2$a <- factor(x = DataSet9.2$a)
#' DataSet9.2$b <- factor(x = DataSet9.2$b)
#'
#'
#' Exam9.2lmer <- lmerTest::lmer(
#'   formula = y ~ a * b + (1|block) + (1|block:a) + (1|block:b),
#'   data    = DataSet9.2
#' )
#' stats::anova(Exam9.2lmer, ddf = "Kenward-Roger")
#'
#' emmeans::emmeans(object = Exam9.2lmer, specs = ~a | b)
#' emmeans::emmip(
#'   object  = emmeans::emmeans(object = Exam9.2lmer, specs = ~a | b),
#'   formula = a ~ b,
#'   ylab    = "y Lsmeans",
#'   main    = "Lsmeans for a*b"
#' )
#'
#' ## Simple effect comparisons of a*b Least Squares Means by a
#' emmeans::emmeans(Exam9.2lmer, pairwise ~ b | a)
#'
#'
NULL
