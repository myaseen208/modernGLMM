#' Data Set 11.3 - Randomized Complete Block Count Data
#'
#' @name DataSet11.3
#' @docType data
#' @usage data(DataSet11.3)
#'
#' @description
#' Three-treatment randomized complete block count data used in Chapter 11,
#' Section 11.4 of Stroup, Ptukhina, and Garai (2024) to illustrate
#' overdispersion in blocked count-data models and alternatives including
#' marginal Poisson, Poisson-normal, negative binomial, and generalized
#' Poisson models.
#'
#' @format A \code{data.frame} with 30 rows and 3 variables:
#' \describe{
#'   \item{block}{Block factor with 10 levels.}
#'   \item{trt}{Treatment factor with 3 levels.}
#'   \item{count}{Non-negative integer count response.}
#' }
#'
#' @details
#' Treatment sample means are exactly \code{8.0}, \code{13.3}, and
#' \code{25.7}, matching the printed marginal means in Section 11.4.1.
#'
#' **Data provenance:** Reconstructed.
#'
#' **Reconstruction method:** Counts were reconstructed from the published
#' treatment sample means and selected model summaries in Chapter 11,
#' Section 11.4. The optimization target used the printed naive Poisson,
#' Poisson-normal, and negative-binomial fitted means, Pearson chi-square/DF,
#' and variance-component summaries as calibration constraints.
#'
#' **Book agreement:** Exact for treatment sample means. Approximate for
#' R-fitted Poisson and negative-binomial GLMM summaries. The printed SAS
#' working-covariance marginal model and generalized Poisson fit are not
#' directly reproducible with base package dependencies.
#'
#' **Limitations:** The original SAS data file was not available in the
#' workspace, the uploaded PDF, or public publisher materials located during
#' verification. Several integer datasets satisfy the printed summaries; this
#' file is a constrained reconstruction, not a confirmed original data file.
#'
#' @references
#' Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#' \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#' Applications}, 2nd ed. CRC Press.
#'
#' @seealso \code{\link{Exam11.3}}
#'
#' @examples
#' data(DataSet11.3)
#' stats::aggregate(count ~ trt, data = DataSet11.3, FUN = mean)
NULL
