#' Data Set 11.4 - Split-Plot Count Data
#'
#' @name DataSet11.4
#' @docType data
#' @usage data(DataSet11.4)
#'
#' @description
#' Split-plot count data for the multi-level Chapter 11 example in
#' Section 11.5 of Stroup, Ptukhina, and Garai (2024). The treatment
#' structure is a 7 by 4 factorial with four blocks.
#'
#' @format A \code{data.frame} with 112 rows and 4 variables:
#' \describe{
#'   \item{block}{Block factor with 4 levels.}
#'   \item{a}{Whole-plot treatment factor with 7 levels.}
#'   \item{b}{Subplot treatment factor with 4 levels.}
#'   \item{count}{Non-negative integer count response.}
#' }
#'
#' @details
#' The data provide a complete 4-block, 7-level \code{a}, 4-level \code{b}
#' split-plot layout for fitting the marginal Poisson and negative-binomial
#' GLMMs described in Chapter 11, Section 11.5.
#'
#' **Data provenance:** Synthetic.
#'
#' **Reconstruction method:** The original raw SAS data were not available.
#' Counts were generated from the printed model-scale and data-scale means
#' for the displayed \code{a = 1} and \code{a = 7} cells, with intermediate
#' \code{a} levels interpolated to preserve the 7 by 4 factorial structure.
#'
#' **Book agreement:** Approximate for the displayed \code{a = 1} and
#' \code{a = 7} fitted mean pattern. Not verified for all 28 cells because
#' the book prints only selected least-squares means.
#'
#' **Limitations:** This dataset is suitable for runnable examples and
#' demonstrations of the Chapter 11 workflow, but it is not a verified copy
#' of the book's original \code{sp_counts} data.
#'
#' @references
#' Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#' \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#' Applications}, 2nd ed. CRC Press.
#'
#' @seealso \code{\link{Exam11.4}}
#'
#' @examples
#' data(DataSet11.4)
#' stats::aggregate(count ~ a + b, data = DataSet11.4, FUN = mean)
NULL
