#' @title Example 10.1 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   Exam10.1
#' @description Exam10.1 One-way random effects model and BLUP estimation
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'      \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'        CRC Press.
#'  }
#'
#' @seealso
#'    \code{\link{DataSet10.1}}
#'
#' @import emmeans lmerTest
#'
#' @examples
#'
#' data(DataSet10.1)
#' DataSet10.1$a <- factor(x = DataSet10.1$a)
#'
#' ## Random effects model
#' Exam10.1lmer <- lme4::lmer(y ~ 1 + (1|a), data = DataSet10.1)
#' summary(Exam10.1lmer)
#'
#' ## Fixed effects model (for comparison)
#' Exam10.1lm <- stats::lm(y ~ a, data = DataSet10.1)
#' summary(Exam10.1lm)
#'
#' ## Overall mean — broad inference (random effects model)
#' emmeans::emmeans(Exam10.1lmer, specs = ~1)
#'
#' ## Overall mean — narrow inference (fixed effects model)
#' emmeans::emmeans(Exam10.1lm, specs = ~1)
#'
#' ## BLUP Estimates and standard errors for each level of a
#' ## SE from conditional variance: sqrt(postVar) matches book Table 10.1 SE = 0.82453
#' blup_coef <- unlist(lme4::ranef(Exam10.1lmer)$a)
#' rv_a      <- lme4::ranef(Exam10.1lmer, condVar = TRUE)
#' BLUPa_SE  <- sqrt(attr(rv_a$a, "postVar")[1, 1, ])
#' BLUPa     <- mean(DataSet10.1$y) + blup_coef
#' print(data.frame(level = rownames(rv_a$a), BLUP = BLUPa, SE = BLUPa_SE))
#'
NULL
