#' @title Data for Example 12.1 — Continuous Proportion Dose-Response (Chapter 12)
#' @name   DataSet12.1
#' @docType data
#' @keywords datasets
#' @usage data(DataSet12.1)
#'
#' @description
#' Continuous proportion data from a dose-response study with two treatments
#' each applied to 12 runs, observed at six dose levels (0–5).  Implements
#' Section 12.6.2 of Stroup et al. (2024), Data Set 12.7 (SAS name
#' \code{rates}).  The response is a continuous proportion suitable for
#' beta regression with a run-level GLMM random effect.
#'
#' \strong{Reconstruction note:} The actual data appear in the SAS Data and
#' Program Library as Data Set 12.7.  This version is reconstructed from the
#' published regression parameters (\eqn{\beta_{0,0}=0.6965},
#' \eqn{\beta_{1,0}=0.2846}; \eqn{\beta_{0,1}=0.8054},
#' \eqn{\beta_{1,1}=0.5541}; p.406) with run random effects drawn from
#' \eqn{N(0, 0.45^2)} and Beta precision \eqn{\phi=10}, using
#' \code{set.seed(2024)}.  Numerical output will approximate published values.
#'
#' @format A \code{data.frame} with 144 rows and 4 variables:
#' \describe{
#'   \item{trt}{Treatment factor with levels 0 and 1}
#'   \item{run}{Run factor with 24 levels (t0r1-t0r12, t1r1-t1r12);
#'     12 runs per treatment, nested within treatment}
#'   \item{dose}{Integer dose level: 0, 1, 2, 3, 4, or 5}
#'   \item{proportion}{Continuous proportion response in \eqn{(0, 1)}}
#' }
#'
#' @details
#' The beta GLMM for the linear dose-response within each treatment is:
#' \deqn{\text{logit}(\mu_{ijk}) = \beta_{0i} + \beta_{1i} D_j + r(\tau)_{ik}}
#' where \eqn{r(\tau)_{ik} \sim \mathcal{N}(0,\sigma^2_r)} is the run random
#' effect nested within treatment, and \eqn{D_j} is the dose level.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts,
#'     Methods and Applications}. CRC Press. Section 12.6.2, pp.404-407.
#'   \item Ferrari, S., & Cribari-Neto, F. (2004).
#'     Beta regression for modelling rates and proportions.
#'     \emph{Journal of Applied Statistics}, 31(7), 799-815.
#' }
#'
#' @seealso \code{\link{Exam12.1}}
#'
#' @examples
#' data(DataSet12.1)
#' str(DataSet12.1)
#' with(DataSet12.1, tapply(proportion, list(trt, dose), mean))
NULL
