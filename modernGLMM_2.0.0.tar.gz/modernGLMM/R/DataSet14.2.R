#' @title Data for Example 14.2 — Non-Proportional Odds: Poinsettia Trial (Chapter 14)
#' @name   DataSet14.2
#' @docType data
#' @keywords datasets
#' @usage data(DataSet14.2)
#'
#' @description
#' Ordinal frequency count data from a poinsettia variety trial with 3 varieties
#' evaluated by 12 growers on a three-category ordered quality rating.  Implements
#' Section 14.4 of Stroup et al. (2024), Data Set 14.2 (SAS name
#' \code{poinsettia}).  The proportional-odds assumption fails (non-proportional
#' odds), requiring separate logistic regressions per category boundary.
#'
#' \strong{Reconstruction note:} The marginal frequency table
#' (variety × rating totals across growers) is transcribed exactly from the
#' published table (p.438 of the 2nd ed.).  Counts are distributed
#' proportionally across 12 growers using \code{set.seed(2024)}.  The actual
#' data appear in the SAS Data and Program Library as Data Set 14.2.
#'
#' @format A \code{data.frame} with 108 rows and 4 variables:
#' \describe{
#'   \item{grower}{Grower identifier (factor with 12 levels); serves as the
#'     GLMM random-effect block}
#'   \item{variety}{Poinsettia variety factor with 3 levels (1, 2, 3)}
#'   \item{rating}{Quality rating factor with levels A, B, C (where A = lowest
#'     quality category and C = highest quality category)}
#'   \item{y}{Frequency count of plants in this grower × variety × rating cell
#'     (non-negative integer)}
#' }
#'
#' @details
#' The proportional-odds (cumulative logit) model assumes a single variety
#' effect across all category boundaries.  The non-proportional-odds model
#' allows variety effects to differ by boundary \eqn{j}:
#' \deqn{\text{logit}[P(Y_{ik} \le j)] = \eta_j - \tau_{ij} - g_k}
#' where \eqn{\tau_{ij}} varies with \eqn{j} and
#' \eqn{g_k \sim \mathcal{N}(0, \sigma^2_g)} is the grower random effect.
#'
#' Published marginal totals (variety × rating, p.438):
#' \tabular{lrrr}{
#'   \tab A \tab B \tab C \cr
#'   v1 \tab 192 \tab 174 \tab 176 \cr
#'   v2 \tab 65 \tab 395 \tab 68 \cr
#'   v3 \tab 262 \tab 30 \tab 244
#' }
#' Published results: proportional odds variety F(2,8)≈0.02, p≈0.98 (fail);
#' non-proportional odds F(4,8)=69.65.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts,
#'     Methods and Applications}. CRC Press. Section 14.4, pp.438-447.
#' }
#'
#' @seealso \code{\link{Exam14.2}}
#'
#' @examples
#' data(DataSet14.2)
#' str(DataSet14.2)
#' ## Marginal totals match published table (book p.438)
#' with(DataSet14.2, tapply(y, list(variety, rating), sum))
NULL
