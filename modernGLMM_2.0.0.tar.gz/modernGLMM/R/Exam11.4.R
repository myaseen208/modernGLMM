#' Example 11.4 - Split-Plot Count Data
#'
#' @name Exam11.4
#'
#' @description
#' Fits the Chapter 11, Section 11.5 split-plot count-data model for a
#' 7 by 4 factorial treatment structure in four blocks.
#'
#' @details
#' The negative-binomial GLMM for the conditional inference target is
#' \deqn{\log(\lambda_{ijk}) = \eta + \alpha_i + \beta_j +
#'       (\alpha\beta)_{ij} + r_k + (ra)_{ik}.}
#'
#' @note
#' The package dataset is synthetic because the original \code{sp_counts}
#' SAS data were not available. Use this example as an executable R analogue
#' of the Chapter 11 workflow rather than as a numerical reproduction of all
#' book tables.
#'
#' @references
#' Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#' \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#' Applications}, 2nd ed. CRC Press.
#'
#' @seealso \code{\link{DataSet11.4}}
#'
#' @examples
#' data(DataSet11.4)
#'
#' if (requireNamespace("glmmTMB", quietly = TRUE)) {
#'   fit_nb <- glmmTMB::glmmTMB(
#'     count ~ a * b + (1 | block) + (1 | block:a),
#'     family = glmmTMB::nbinom2(link = "log"),
#'     data = DataSet11.4
#'   )
#'   summary(fit_nb)
#'   emmeans::emmeans(fit_nb, specs = ~ a * b, type = "response")
#'
#'   if (requireNamespace("DHARMa", quietly = TRUE)) {
#'     sim_res <- DHARMa::simulateResiduals(fit_nb, plot = FALSE)
#'     DHARMa::testDispersion(sim_res)
#'   }
#'
#'   if (requireNamespace("report", quietly = TRUE)) {
#'     report::report(fit_nb)
#'   }
#' }
NULL
