#' @title Example 2.B.4 from Generalized Linear Mixed Models: Modern Concepts, Methods and Applications by Stroup, Ptukhina, and Garai (2024, 2nd ed.)
#' @name   Exam2.B.4
#' @description Exam2.B.4 is used to illustrate one way treatment design with Binomial observations.
#' @author \enumerate{
#'          \item  Muhammad Yaseen (\email{myaseen208@@gmail.com})
#'          \item Adeela Munawar (\email{adeela.uaf@@gmail.com})
#'          }
#' @references \enumerate{
#' \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'      \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and Applications (2nd ed.)}.
#'        CRC Press.
#'  }
#' @seealso
#'    \code{\link{DataExam2.B.4}}
#'
#' @import parameters
#' @importFrom stats glm summary.glm
#'
#' @examples
#' #-----------------------------------------------------------------------------------
#' ## logit Model  discussed in Example 2.B.2 using DataExam2.B.4
#' ## Default link is logit
#' ## using fmaily=binomial gives warning message of no-integer successes
#' #-----------------------------------------------------------------------------------
#' data(DataExam2.B.4)
#' DataExam2.B.4$trt <- factor(x =  DataExam2.B.4$trt)
#' Exam2.B.4glm <-
#'                 glm(
#'                       formula = Yij/Nij ~ trt
#'                     , family  =  quasibinomial(link = "probit")
#'                     , data    = DataExam2.B.4
#'                     )
#' summary(Exam2.B.4glm)
#' parameters::model_parameters(Exam2.B.4glm)
NULL
