#' @title Example 17.2 — Repeated Measures: SP(POW) with Unequal Spacing
#' @name   Exam17.2
#'
#' @description
#' Analysis of sparse longitudinal data (41 subjects, 2 treatments, 9 unequally-
#' spaced times) using a random coefficient model with spatial-power SP(POW)
#' covariance.  Implements Example 17.3.2 of Stroup et al. (2024), Data Set 17.2.
#' Demonstrates heterogeneous covariance by treatment and how SP(POW) generalises
#' AR(1) to irregular time grids.
#'
#' @details
#' For unequally-spaced observations at actual times \eqn{X_1 = 0, X_2 = 1,
#' X_3 = 2, X_4 = 4, \ldots, X_9 = 128}, the SP(POW) covariance between
#' observations \eqn{j} and \eqn{j'} on the same subject is:
#' \deqn{\text{Cov}(e_j, e_{j'}) = \sigma^2 \rho^{|X_j - X_{j'|}}}
#' Unlike AR(1), SP(POW) accommodates unequal spacing and missing observations
#' naturally.  Heterogeneous SP(POW) allows \eqn{\sigma^2} and \eqn{\rho} to
#' differ between treatments.
#'
#' The random coefficient model is:
#' \deqn{y_{ik} = \beta_{0i} + b_{0k} + (\beta_{1i} + b_{1k}) X_j + e_{ijk}}
#' where \eqn{X_j} is the continuous time covariate.
#'
#' Published results (2nd ed. p.517-518):
#' AICC: CS=583.67, AR(1)=585.77, SP(POW)=586.54 (homogeneous);
#' CS=579.07, AR(1)=577.75, SP(POW)=575.96 (heterogeneous by treatment).
#' Heterogeneous SP(POW) selected; homogeneity test: chi-sq=8.65, p=0.0132.
#'
#' @note
#' \strong{Dataset note:} \code{DataSet17.2} is reconstructed from the
#' published design description: 41 subjects (17 on trt=1, 24 on trt=2),
#' 9 unequal times (0,1,2,4,8,16,32,64,128), only 101 of 369 possible
#' observations present (sparse).  Synthetic response values are generated
#' using the published random coefficient model as the approximate generative
#' model.  The actual data appear in the SAS Data and Program Library as
#' Data Set 17.2 (SAS name \code{all}).  Published AICC and parameter
#' estimates will not be reproduced exactly.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts, Methods and
#'     Applications}. CRC Press. Section 17.3.2, pp.516–518.
#'   \item Littell, R.C., Milliken, G.A., Stroup, W.W., Wolfinger, R.D.,
#'     & Schabenberger, O. (2006). \emph{SAS for Mixed Models}, 2nd ed.
#'     SAS Institute.
#' }
#'
#' @seealso \code{\link{DataSet17.2}}
#'
#' @examples
#' data(DataSet17.2)
#'
#' ## -------------------------------------------------------
#' ## 1. Data overview
#' ## -------------------------------------------------------
#' cat("Observations per treatment:\n")
#' print(table(DataSet17.2$trt))
#' cat("Times observed:\n")
#' print(sort(unique(DataSet17.2$time)))
#'
#' ## -------------------------------------------------------
#' ## 2. Covariance model comparison: CS, AR(1), SP(POW)
#' ## -------------------------------------------------------
#'
#' ## CS model (compound symmetry via random intercept)
#' fit_cs <- nlme::lme(
#'   fixed  = y ~ trt * time,
#'   random = ~ 1 | subject,
#'   data   = DataSet17.2,
#'   method = "REML",
#'   control = nlme::lmeControl(opt = "optim")
#' )
#'
#' ## AR(1) model (may fail on unequally-spaced data — corAR1 assumes equal spacing)
#' fit_ar1 <- tryCatch(
#'   nlme::lme(
#'     fixed       = y ~ trt * time,
#'     random      = ~ 1 | subject,
#'     correlation = nlme::corAR1(form = ~ time | subject),
#'     data        = DataSet17.2,
#'     method      = "REML",
#'     control     = nlme::lmeControl(opt = "optim")
#'   ),
#'   error = function(e) {
#'     message("AR(1) failed (expected for unequal spacing): ", conditionMessage(e))
#'     NULL
#'   }
#' )
#'
#' ## SP(POW): spatial-power ~ exponential for unequal times
#' fit_sppow <- nlme::lme(
#'   fixed       = y ~ trt * time,
#'   random      = ~ 1 | subject,
#'   correlation = nlme::corExp(
#'     form   = ~ time | subject,
#'     nugget = FALSE
#'   ),
#'   data        = DataSet17.2,
#'   method      = "REML",
#'   control     = nlme::lmeControl(opt = "optim")
#' )
#'
#' ## AIC comparison (only non-NULL models)
#' aic_models <- Filter(Negate(is.null), list(CS = fit_cs, AR1 = fit_ar1, SPPOW = fit_sppow))
#' if (length(aic_models) > 0) print(sapply(aic_models, stats::AIC))
#'
#' ## -------------------------------------------------------
#' ## 3. Random coefficient model with best covariance
#' ## -------------------------------------------------------
#' fit_rc <- nlme::lme(
#'   fixed       = y ~ trt + time + trt:time,
#'   random      = ~ 1 + time | subject,
#'   correlation = nlme::corExp(form = ~ time | subject),
#'   data        = DataSet17.2,
#'   method      = "REML",
#'   control     = nlme::lmeControl(opt = "optim", maxIter = 200)
#' )
#' summary(fit_rc)
#'
#' ## -------------------------------------------------------
#' ## 4. Treatment effects and predicted profiles
#' ## -------------------------------------------------------
#' emm_trt <- emmeans::emmeans(fit_rc, ~ trt,
#'                              at = list(time = c(0, 1, 4, 16, 64)))
#' print(emm_trt)
#'
#' ## Equal slopes test
#' emm_slp <- emmeans::emtrends(fit_rc, ~ trt, var = "time")
#' emmeans::contrast(emm_slp, method = "pairwise")
NULL
