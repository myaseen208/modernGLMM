#' @title Data for Example 12.2 — Binomial Nested Factorial (Chapter 12)
#' @name   DataSet12.2
#' @docType data
#' @keywords datasets
#' @usage data(DataSet12.2)
#'
#' @description
#' Binomial count data from a nested factorial design with factor A (2 levels,
#' representing two sets) and factor B (3 levels nested within A), replicated
#' across 10 blocks (5 blocks per set).  Implements Section 12.3.2 of
#' Stroup et al. (2024), Data Set 12.2 (SAS name \code{ch11_ex_12C2}).
#' The response is the number of successes out of a fixed total, suitable for
#' binomial GLMM analysis.
#'
#' \strong{Reconstruction note:} The actual data appear in the SAS Data and
#' Program Library as Data Set 12.2.  This version is reconstructed from the
#' published design description (5 blocks × setA + 5 blocks × setB, 3
#' treatments B0/B1/B2 per block, N=20 per cell, 30 obs total) and the
#' published logit B(A) LSMeans (p.382) using \code{set.seed(123)}.
#' Numerical output will approximate published values.
#'
#' @format A \code{data.frame} with 30 rows and 5 variables:
#' \describe{
#'   \item{block}{Block factor with 10 levels (1–10); blocks 1–5 are
#'     assigned to \code{setA}, blocks 6–10 to \code{setB}}
#'   \item{a}{Set factor with 2 levels (\code{setA}, \code{setB});
#'     each set assigned to 5 blocks (whole-plot factor)}
#'   \item{b}{Treatment factor nested within A, with 3 levels
#'     (\code{B0}, \code{B1}, \code{B2}) within each set}
#'   \item{f}{Number of successes (integer count)}
#'   \item{n}{Total number of trials per cell (integer, N=20)}
#' }
#'
#' @details
#' The binomial GLMM for the nested factorial structure is:
#' \deqn{\text{logit}(\pi_{ijk}) = \eta + \alpha_i + \beta_{j(i)} + r_{k(i)}}
#' where \eqn{\alpha_i} is the set (A) effect, \eqn{\beta_{j(i)}} is the
#' treatment B nested within A, and \eqn{r_{k(i)} \sim
#' \mathcal{N}(0, \sigma^2_A)} is the block-within-A random effect
#' (whole-plot error).
#'
#' Published results (2nd ed. p.382):
#' \eqn{\hat\sigma^2_A = 0.4784} (SE=0.2664); A: F(1,8)=0.46, p=0.5187;
#' B(A): F(4,16)=2.43, p=0.0907.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts,
#'     Methods and Applications}. CRC Press. Section 12.3.2, pp.388-392.
#' }
#'
#' @seealso \code{\link{Exam12.2}}
#'
#' @examples
#' data(DataSet12.2)
#' str(DataSet12.2)
#' with(DataSet12.2, tapply(f / n, list(a, b), mean))
NULL
