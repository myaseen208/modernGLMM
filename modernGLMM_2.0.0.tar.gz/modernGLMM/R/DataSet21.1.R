#' @title Data for Example 21.1 — Power Curve for One-Way ANOVA (Chapter 21)
#' @name   DataSet21.1
#' @docType data
#' @keywords datasets
#' @usage data(DataSet21.1)
#'
#' @description
#' Pre-computed power values for a balanced one-way ANOVA (3 treatments)
#' across a grid of sample sizes and standardised effect sizes.
#' Suitable for plotting power curves and selecting sample sizes.
#'
#' @format A \code{data.frame} with 30 rows and 3 variables:
#' \describe{
#'   \item{n_per_group}{Sample size per treatment group (5–50, step 5)}
#'   \item{effect_size}{Cohen's \eqn{f} effect size (0.2, 0.5, or 0.8)}
#'   \item{power}{Estimated power (0–1)}
#' }
#'
#' @details
#' Power for a one-way ANOVA F-test is computed using the non-central F
#' distribution with non-centrality parameter
#' \deqn{\lambda = n \cdot k \cdot f^2}
#' where \eqn{n} is the per-group sample size, \eqn{k} is the number of
#' groups, and \eqn{f} is Cohen's f effect size.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts,
#'     Methods and Applications}. CRC Press.
#'   \item Cohen, J. (1988).
#'     \emph{Statistical Power Analysis for the Behavioral Sciences},
#'     2nd ed. Lawrence Erlbaum Associates.
#' }
#'
#' @seealso \code{\link{Exam21.1}}
#'
#' @examples
#' data(DataSet21.1)
#' str(DataSet21.1)
NULL
