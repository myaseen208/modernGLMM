#' @title Data for Example 14.1 — Ordinal Proportional Odds GLMM (Chapter 14)
#' @name   DataSet14.1
#' @docType data
#' @keywords datasets
#' @usage data(DataSet14.1)
#'
#' @description
#' Ordinal frequency count data from a randomised complete block design with
#' 6 treatments and 10 blocks.  The response is a three-category ordered rating
#' (slight, moderate, severe).  Implements Section 14.3 of Stroup et al. (2024),
#' Data Set 14.1 (SAS name \code{univar_multinom}).  Suitable for proportional-odds
#' (cumulative logit) GLMM analysis.
#'
#' \strong{Reconstruction note:} The first 9 rows (block 1, treatments 0–2)
#' are transcribed exactly from the published table (p.435 of the 2nd ed.).
#' The remaining 171 rows are reconstructed from the published cumulative-logit
#' parameters (\eqn{\hat\eta_0=0.3492}, \eqn{\hat\eta_1=1.9956}, treatment
#' effects pp.436-437) using \code{set.seed(2024)}.  The actual data appear in
#' the SAS Data and Program Library as Data Set 14.1.
#'
#' @format A \code{data.frame} with 180 rows and 4 variables:
#' \describe{
#'   \item{blk}{Block factor with 10 levels (1–10)}
#'   \item{trt}{Treatment factor with 6 levels (0–5)}
#'   \item{rating}{Ordered factor with levels \code{slight} < \code{modrat} <
#'     \code{severe}}
#'   \item{y}{Frequency count of observations in this blk × trt × rating cell
#'     (non-negative integer)}
#' }
#'
#' @details
#' The proportional-odds GLMM for treatment \eqn{i} in block \eqn{k} with
#' ordinal category \eqn{j} is:
#' \deqn{\text{logit}[P(Y_{ik} \le j)] = \eta_j - \tau_i - b_k}
#' where \eqn{\eta_j} are the cumulative intercept thresholds,
#' \eqn{\tau_i} is the treatment fixed effect, and
#' \eqn{b_k \sim \mathcal{N}(0, \sigma^2_b)} is the block random effect.
#'
#' Published results (2nd ed. pp.436-437):
#' \eqn{\hat\eta_0=0.3492}, \eqn{\hat\eta_1=1.9956};
#' Treatment F(5,768)=17.67, p<0.0001.
#'
#' @references
#' \enumerate{
#'   \item Stroup, W. W., Ptukhina, M., and Garai, S. (2024).
#'     \emph{Generalized Linear Mixed Models: Modern Concepts,
#'     Methods and Applications}. CRC Press. Section 14.3, pp.434-438.
#'   \item Agresti, A. (2010). \emph{Analysis of Ordinal Categorical Data},
#'     2nd ed. Wiley.
#' }
#'
#' @seealso \code{\link{Exam14.1}}
#'
#' @examples
#' data(DataSet14.1)
#' str(DataSet14.1)
#' with(DataSet14.1, tapply(y, list(trt, rating), sum))
NULL
